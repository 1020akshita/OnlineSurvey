/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package survey;

/**
 *
 * @author Asus
 */
import java.sql.*;
public class Connn {
    Connection c;
    Statement s;
    Connn(){
    try{
Class.forName("com.mysql.cj.jdbc.Driver");
c= DriverManager.getConnection("jdbc:mysql://localhost:3305/onlinesurvey" ,"root" ,"1234");
s= c.createStatement();
}
    catch(Exception e)
    {

        e.printStackTrace();
    }
    }
    
    public static void main(String[]args)
    {
    }
}


